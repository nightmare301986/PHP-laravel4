<!doctype html>
<html>
  <head>
   header
  </head>
  <body>
 header
    
  </body>
</html><?php /**PATH /home/runner/LateDisguisedCodes/resources/views/includes/header.blade.php ENDPATH**/ ?>