<!doctype html>
<html>
  <head>

  </head>
  <body>
<p>head</p> 
  </body>
</html><?php /**PATH /home/runner/LateDisguisedCodes/resources/views/includes/head.blade.php ENDPATH**/ ?>