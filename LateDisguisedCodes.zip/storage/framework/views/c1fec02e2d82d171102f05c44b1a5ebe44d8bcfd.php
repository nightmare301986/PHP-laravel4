<!doctype html>
<html>
  <head>
   111
  </head>
  <body>


<?php $__env->startSection('content'); ?>

   Hello <?php echo e($email); ?>

    <?php if($email == null): ?> Вы не вошли в систему.
    <?php else: ?>  Вы вошли в систему.
    <?php endif; ?>

<?php $__env->stopSection(); ?>

  </body>
</html>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/runner/LateDisguisedCodes/resources/views/contacts.blade.php ENDPATH**/ ?>