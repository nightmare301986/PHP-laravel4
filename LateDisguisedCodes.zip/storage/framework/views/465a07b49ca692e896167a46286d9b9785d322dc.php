<!doctype html>
<html>
  <head>
   footer
  </head>
  <body>
 footer
    
  </body>
</html><?php /**PATH /home/runner/LateDisguisedCodes/resources/views/includes/footer.blade.php ENDPATH**/ ?>